function ImDenoised = saltpepperdenoising(ImNoisy,kernelDim)
    
    [size_line, size_column, rgb, ~] = size(ImNoisy);
    kernel = zeros(kernelDim,kernelDim);
    ImDenoised = ImNoisy;
    
    for ch = 1 : rgb
        for i = floor(kernelDim/2) : size_line - ceil(kernelDim/2)
            for j = floor(kernelDim/2) : size_column - ceil(kernelDim/2)
                for k = 1 : kernelDim
                    for l = 1 : kernelDim
                        kernel(k,l) = ImNoisy(i+k-floor(kernelDim/2),j+l-floor(kernelDim/2),ch);  
                    end
                end
                denoisedPix = median(unique(sort(kernel)'));
                ImDenoised(i,j,ch) = denoisedPix;
            end
        end
    end
end