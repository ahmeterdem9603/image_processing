clear all; close all; clc;

ImNoisy = imread('cameraman.png');
ImNoisy = imnoise(ImNoisy,'salt & pepper', 0.5);

figure; imshow(ImNoisy);

ImDenoised = saltpepperdenoising(ImNoisy,3);

figure; imshow(uint8(ImDenoised));